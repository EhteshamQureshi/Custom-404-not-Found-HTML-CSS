Hello, I'm looking to have made a custom "404 Not Found" page. 
The page will be dark/black with a centered background image (bg.jpg), 
and I want to have the three other images (layer1.png, layer2.png, layer3.png) 
stacked and centered in the middle aligned with the background and made so that 
they are spinning at varied rates. Then somewhere have the white text saying "404 Not Found" 
I will leave this to your best judgement on where to position the text at. 
I'll also include my own attempt for you to view in the index.html file. 
I would also like it if possible so the layer images can't be selected or right clicked
 on same as how the background image is and only the 404 message text is selected 
if you try to select something on the page.

Please let me know if there is anything else or any questions for me, Thank you!
